import type { Db } from 'mongodb';

export async function createIndexes(db: Db) {
  // Products
  await db.collection('products').createIndex({ cafeId: 1 });
  await db.collection('products').createIndex({ categoryId: 1 });
  
  // Orders
  await db.collection('orders').createIndex({ cafeId: 1 });
  await db.collection('orders').createIndex({ createdAt: -1 });
  await db.collection('orders').createIndex({ invoiceNumber: 1 });
  await db.collection('orders').createIndex({ status: 1 });
  await db.collection('orders').createIndex({ paymentMethod: 1 });

  // Users
  await db.collection('users').createIndex({ cafeId: 1 });
  await db.collection('users').createIndex({ username: 1 }, { unique: true });

  // Payments
  await db.collection('payments').createIndex({ orderId: 1 });
  await db.collection('payments').createIndex({ cafeId: 1 });

  console.log('✅ Database Indexes ensured.');
}
