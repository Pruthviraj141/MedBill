import { jwt } from 'hono/jwt';
import type { Role } from '../models/types';
import type { Context, Next } from 'hono';

export const authMiddleware = () => {
  return async (c: Context, next: Next) => {
    const secret = c.env.AUTH_SECRET || 'changeme_to_secure_secret';
    
    const jwtMiddleware = jwt({
      secret: secret,
      alg: 'HS256'
    });
    return jwtMiddleware(c, next);
  };
};

export const requireRole = (allowedRoles: Role[]) => {
  return async (c: Context, next: Next) => {
    const payload = c.get('jwtPayload') as any;
    if (!payload || !payload.role || !allowedRoles.includes(payload.role as Role)) {
      return c.json({ ok: false, error: 'Unauthorized role access' }, 403);
    }
    await next();
  };
};
