const { MongoClient } = require('mongodb');

const uri = 'mongodb+srv://pruthvi:pruthvi@cluster0.bnu6x.mongodb.net/?appName=Cluster0';

async function testConnection() {
  console.log('Connecting to:', uri.replace(/:([^:@]+)@/, ':****@'));
  const client = new MongoClient(uri);
  try {
    await client.connect();
    console.log('✅ Successfully connected to MongoDB Atlas!');
    const collections = await client.db('cafe').listCollections().toArray();
    console.log('Available collections:', collections.map(c => c.name));
  } catch (err) {
    console.error('❌ Failed to connect to MongoDB Atlas!');
    console.error(err.message);
  } finally {
    await client.close();
  }
}

testConnection();
