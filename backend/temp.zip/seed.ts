import { MongoClient } from 'mongodb';
import * as fs from 'fs';
import * as path from 'path';

const varsPath = fs.existsSync('./.env') ? './.env' : './.dev.vars';
let uri = 'mongodb+srv://user:pass@cluster.mongodb.net/';
let dbName = 'cafepos';

if (fs.existsSync(varsPath)) {
  const content = fs.readFileSync(varsPath, 'utf8');
  const matchUri = content.match(/MONGODB_URI=(.*)/);
  const matchDbName = content.match(/MONGODB_DB_NAME=(.*)/);
  if (matchUri) uri = matchUri[1].trim();
  if (matchDbName) dbName = matchDbName[1].trim();
}

// Full TBT CAFE MENU transcribed exactly (with minor typo corrections for professionalism, e.g. 'chess' -> 'cheese')
const products = [
  // PIZZA 🍕
  { name: 'Margarita Pizza', category: 'Pizza', price: 100, icon: '🍕', stockTracking: false, active: true },
  { name: 'Corn Cheese Pizza', category: 'Pizza', price: 110, icon: '🍕', stockTracking: false, active: true },
  { name: 'Farmhouse Pizza', category: 'Pizza', price: 170, icon: '🍕', stockTracking: false, active: true },
  { name: 'Paneer Pizza', category: 'Pizza', price: 150, icon: '🍕', stockTracking: false, active: true },
  { name: 'Vegie Pizza', category: 'Pizza', price: 150, icon: '🍕', stockTracking: false, active: true },
  
  // SANDWICH 🥪
  { name: 'Veg Cheese Grill Sandwich', category: 'Sandwich', price: 100, icon: '🥪', stockTracking: false, active: true },
  { name: 'Paneer Grill Sandwich', category: 'Sandwich', price: 120, icon: '🥪', stockTracking: false, active: true },
  { name: 'Club Sandwich', category: 'Sandwich', price: 70, icon: '🥪', stockTracking: false, active: true },
  { name: 'Corn Cheese Sandwich', category: 'Sandwich', price: 120, icon: '🥪', stockTracking: false, active: true },

  // BURGER 🍔
  { name: 'Aloo Tikki Burger', category: 'Burger', price: 90, icon: '🍔', stockTracking: false, active: true },
  { name: 'Aloo Cheese Burger', category: 'Burger', price: 120, icon: '🍔', stockTracking: false, active: true },
  { name: 'Paneer Burger', category: 'Burger', price: 130, icon: '🍔', stockTracking: false, active: true },
  { name: 'Peri Peri Burger', category: 'Burger', price: 150, icon: '🍔', stockTracking: false, active: true },

  // PASTA 🍝
  { name: 'White Sauce Pasta', category: 'Pasta', price: 180, icon: '🍝', stockTracking: false, active: true },
  { name: 'Red Sauce Pasta', category: 'Pasta', price: 180, icon: '🍝', stockTracking: false, active: true },
  { name: 'Mix Sauce Pasta', category: 'Pasta', price: 200, icon: '🍝', stockTracking: false, active: true },

  // TOAST 🍞
  { name: 'Garlic Toast', category: 'Toast', price: 110, icon: '🍞', stockTracking: false, active: true },
  { name: 'Cheese Chili Toast', category: 'Toast', price: 120, icon: '🍞', stockTracking: false, active: true },

  // NACHOS 🌮
  { name: 'Salsa Nachos', category: 'Nachos', price: 110, icon: '🌮', stockTracking: false, active: true },
  { name: 'Loaded Nachos', category: 'Nachos', price: 140, icon: '🌮', stockTracking: false, active: true },

  // FRIES 🍟
  { name: 'Salted Fries', category: 'Fries', price: 70, icon: '🍟', stockTracking: false, active: true },
  { name: 'Masala Fries', category: 'Fries', price: 100, icon: '🍟', stockTracking: false, active: true },
  { name: 'Peri Peri Fries', category: 'Fries', price: 80, icon: '🍟', stockTracking: false, active: true },
  { name: 'Cheese Fries', category: 'Fries', price: 150, icon: '🍟', stockTracking: false, active: true },
  { name: 'Loaded Fries', category: 'Fries', price: 160, icon: '🍟', stockTracking: false, active: true },

  // MAGGI 🍜
  { name: 'Masala Maggi', category: 'Maggi', price: 80, icon: '🍜', stockTracking: false, active: true },
  { name: 'Vegetable Maggi', category: 'Maggi', price: 110, icon: '🍜', stockTracking: false, active: true },
  { name: 'Cheese Maggi', category: 'Maggi', price: 100, icon: '🍜', stockTracking: false, active: true },
  { name: 'Tandoor Maggi', category: 'Maggi', price: 110, icon: '🍜', stockTracking: false, active: true },

  // SPAGHETTI 🍝
  { name: 'Red Sauce Spaghetti', category: 'Spaghetti', price: 200, icon: '🍝', stockTracking: false, active: true },
  { name: 'White Sauce Spaghetti', category: 'Spaghetti', price: 200, icon: '🍝', stockTracking: false, active: true },
  { name: 'Mix Sauce Spaghetti', category: 'Spaghetti', price: 250, icon: '🍝', stockTracking: false, active: true },

  // DESSERT 🍰
  { name: 'Brownie Sizzling', category: 'Dessert', price: 150, icon: '🍫', stockTracking: false, active: true },
  { name: 'Plain Brownie', category: 'Dessert', price: 110, icon: '🍫', stockTracking: false, active: true },
  { name: 'Fudge Brownie', category: 'Dessert', price: 120, icon: '🍫', stockTracking: false, active: true },

  // COFFEE ☕
  { name: 'Plain Cold Coffee', category: 'Coffee', price: 80, icon: '🧋', stockTracking: false, active: true },
  { name: 'Irish Cold Coffee', category: 'Coffee', price: 100, icon: '🧋', stockTracking: false, active: true },
  { name: 'Chocolate Cold Coffee', category: 'Coffee', price: 100, icon: '🧋', stockTracking: false, active: true },
  { name: 'Hazelnut Cold Coffee', category: 'Coffee', price: 100, icon: '🧋', stockTracking: false, active: true },
  { name: 'Cold Coffee with Ice Cream', category: 'Coffee', price: 100, icon: '🧋', stockTracking: false, active: true },
  { name: 'Brownie Cold Coffee', category: 'Coffee', price: 150, icon: '🧋', stockTracking: false, active: true },

  // SHAKE 🥤
  { name: 'Strawberry Shake', category: 'Shake', price: 90, icon: '🥤', stockTracking: false, active: true },
  { name: 'Mango Shake', category: 'Shake', price: 90, icon: '🥤', stockTracking: false, active: true },
  { name: 'Chocolate Milk Shake', category: 'Shake', price: 90, icon: '🥤', stockTracking: false, active: true },
  { name: 'Brownie Milk Shake', category: 'Shake', price: 110, icon: '🥤', stockTracking: false, active: true },

  // NUGGETS 🍗
  { name: 'Corn Cheese Ball', category: 'Nuggets', price: 130, icon: '🍘', stockTracking: false, active: true },
  { name: 'Potato Cheese Ball', category: 'Nuggets', price: 110, icon: '🍘', stockTracking: false, active: true },

  // MOCKTAIL 🍹
  { name: 'Mojito', category: 'Mocktail', price: 90, icon: '🍹', stockTracking: false, active: true },
  { name: 'Green AppleMocktail', category: 'Mocktail', price: 90, icon: '🍹', stockTracking: false, active: true },
  { name: 'Lemonade', category: 'Mocktail', price: 90, icon: '🍹', stockTracking: false, active: true },
  { name: 'Masala Lemonade', category: 'Mocktail', price: 110, icon: '🍹', stockTracking: false, active: true },
];

async function seed() {
  if (uri.includes('user:pass')) {
    console.error('❌ MONGODB_URI is still set to placeholder in .dev.vars!');
    console.error('Please configure your real MongoDB Atlas credentials in backend/.dev.vars and run this again.');
    process.exit(1);
  }

  const client = new MongoClient(uri);
  try {
    await client.connect();
    const db = client.db(dbName);
    
    await db.collection('products').deleteMany({ cafeId: 'cafe_1' });
    
    // Inject required backend tracked fields
    const formattedProducts = products.map((p: any) => ({
      ...p,
      cafeId: 'cafe_1',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    }));

    const result = await db.collection('products').insertMany(formattedProducts);
    
    // Inject a test user to allow the user to actually log in to the UI
    await db.collection('users').deleteMany({ username: 'admin' });
    await db.collection('users').insertOne({
      username: 'admin',
      passwordHash: 'admin', // Simple for testing Stage 2
      role: 'OWNER',
      cafeId: 'cafe_1',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    console.log(`✅ Menu successfully seeded! Inserted ${result.insertedCount} items.`);
    console.log(`✅ Default admin user created (Username: admin, Password: admin)`);
  } catch(e) {
    console.error("❌ Seed failed: ", e);
  } finally {
    await client.close();
  }
}

seed();
